export default function AdminFilesPage() {
  return (
    <div className="min-h-screen p-8">
      <h1 className="text-3xl font-bold mb-4">Files Management</h1>
      <p className="text-gray-600">File uploads and document management will be handled here.</p>
    </div>
  )
}