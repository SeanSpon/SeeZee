export default function Page() {
  return (
    <main className="container mx-auto py-12">
      <h1 className="text-3xl font-bold">Checkout</h1>
      <p>Replace me with the real content.</p>
    </main>
  );
}