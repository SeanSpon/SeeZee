-- AlterTable
ALTER TABLE "leads" ALTER COLUMN "updatedAt" DROP DEFAULT;
