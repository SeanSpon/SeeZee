import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { Role } from "@prisma/client";

// Define protected routes and their required roles
const protectedRoutes = {
  "/portal": ["ADMIN", "STAFF"],
  "/portal/dashboard": ["ADMIN", "STAFF"], 
  "/portal/leads": ["ADMIN", "STAFF"],
  "/portal/messages": ["ADMIN", "STAFF"],
  "/portal/projects": ["ADMIN", "STAFF"],
  "/portal/invoices": ["ADMIN", "STAFF"],
  "/portal/files": ["ADMIN", "STAFF"],
  "/portal/settings": ["ADMIN"],
  
  // Legacy admin routes (will redirect to portal)
  "/admin": ["ADMIN", "STAFF"],
  "/dashboard": ["ADMIN", "STAFF"],
} as const;

// Public routes that don't require authentication
const publicRoutes = [
  "/",
  "/about", 
  "/services",
  "/contact",
  "/work",
  "/legal/privacy",
  "/legal/terms",
  "/login",
  "/logout",
];

// API routes that need protection
const protectedApiRoutes = {
  "/api/dashboard": ["ADMIN", "STAFF"],
  "/api/leads": ["ADMIN", "STAFF"],
  "/api/messages": ["ADMIN", "STAFF"],
  "/api/projects": ["ADMIN", "STAFF"],
  "/api/invoices": ["ADMIN", "STAFF"],
} as const;

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  // Skip middleware for static files, Next.js internals, and auth routes
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api/auth") ||
    pathname.includes(".") // Static files
  ) {
    return NextResponse.next();
  }

  // Check if route is public
  if (publicRoutes.some(route => pathname === route || pathname.startsWith(route + "/"))) {
    return NextResponse.next();
  }

  // Get the token to check authentication and role
  const token = await getToken({ 
    req: request, 
    secret: process.env.NEXTAUTH_SECRET 
  });

  // Handle legacy admin routes - redirect to portal
  if (pathname.startsWith("/admin") || pathname === "/dashboard") {
    const portalPath = pathname.replace("/admin", "/portal").replace("/dashboard", "/portal/dashboard");
    return NextResponse.redirect(new URL(portalPath, request.url));
  }

  // Check if route requires authentication
  const requiredRoles = protectedRoutes[pathname as keyof typeof protectedRoutes] ||
                       protectedApiRoutes[pathname as keyof typeof protectedApiRoutes];

  if (requiredRoles) {
    // No token means user is not logged in
    if (!token) {
      return NextResponse.redirect(new URL("/login", request.url));
    }

    // Check if user has required role
    const userRole = token.role as string;
    if (!requiredRoles.includes(userRole as any)) {
      // User doesn't have required role
      return NextResponse.redirect(new URL("/unauthorized", request.url));
    }
  }

  // Add debug headers for development
  if (process.env.NODE_ENV === "development") {
    const response = NextResponse.next();
    response.headers.set("x-debug-pathname", pathname);
    response.headers.set("x-debug-auth", token ? "authenticated" : "anonymous");
    response.headers.set("x-debug-role", token?.role?.toString() || "none");
    response.headers.set("x-debug-required-roles", requiredRoles?.join(",") || "none");
    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api/auth (NextAuth routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!api/auth|_next/static|_next/image|favicon.ico).*)",
  ],
};
