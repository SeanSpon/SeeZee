// Placeholder component - not currently used
export function CheckoutStep() {
  return null
}