export function TechStrip() {
  return (
    <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 h-1 w-full" />
  )
}