import { NextAuthOptions } from "next-auth";
import Google from "next-auth/providers/google";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "../server/db/prisma";
import { Role } from "@prisma/client";

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],
  session: { strategy: "jwt" },
  secret: process.env.NEXTAUTH_SECRET,
  pages: {
    signIn: "/login",
    signOut: "/logout",
  },
  callbacks: {
    async jwt({ token, user }) {
      // If this is a new user sign-in, get their role from the database
      if (user) {
        const dbUser = await prisma.user.findUnique({
          where: { email: user.email! },
          select: { id: true, role: true }
        });
        
        if (dbUser) {
          token.role = dbUser.role;
          token.userId = dbUser.id;
        }
      }
      return token;
    },
    async session({ session, token }) {
      // Pass role and userId to session
      if (token && session.user) {
        session.user.role = token.role as Role;
        session.user.id = token.userId as string;
      }
      return session;
    }
  }
};

// Helper function to check if user has required role
export function hasRole(userRole: Role, requiredRoles: Role[]): boolean {
  return requiredRoles.includes(userRole);
}

// Helper function to check if user is admin
export function isAdmin(userRole: Role): boolean {
  return userRole === ("ADMIN" as any);
}

// Helper function to check if user is staff or admin  
export function isStaffOrAdmin(userRole: Role): boolean {
  return userRole === ("ADMIN" as any) || userRole === ("STAFF" as any);
}